const Menu = [
  {
    label: 'Home',
    pathname: '/',
  },
  {
    label: 'Team',
    pathname: '/team',
  },
  {
    label: 'Projects',
    pathname: '/projects',
  },
  // {
  //   label: 'Ideas',
  //   pathname: '/ideas',
  // },
  {
    label: 'Events',
    pathname: '/events',
  },
  {
    label: 'Resources',
    pathname: '/misc',
  },
  {
    label: 'Contact Us',
    pathname: '/contact',
  },
];

export default Menu;
