// export const membersAPI = 'http://www.mocky.io/v2/5c51c111340000f952129fd2';
export const membersAPI = 'https://dboards.devclub.in/api/user/getAll';

// export const projectsAPI = 'http://www.mocky.io/v2/5cf96042340000fb2b01b4f7';
export const projectsAPI = 'https://dboards.devclub.in/api/project/getAll';

// export const resourcesAPI = 'http://www.mocky.io/v2/5c51cc44320000ca028558f6';
export const resourcesAPI = 'https://dboards.devclub.in/api/resource/getAll';

// export const eventsAPI = 'http://www.mocky.io/v2/5c51cc6232000036028558f8';
export const eventsAPI = 'https://dboards.devclub.in/api/event/getAll';

export const disqusShortname = 'devclub-in-1';
export const urlBase = 'https://www.devclub.in/';
